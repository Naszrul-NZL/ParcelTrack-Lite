# ParcelTrack Lite checkpoint demo

Extract the entire ZIP into a folder before running. Install Node.js 22.14 or newer if needed. On Windows, double-click start-demo.cmd, then open the local address printed in its window. Keep that window open. On other systems run `node serve-demo.mjs` from this folder. The compiled frontend is included in dist; no npm installation or internet connection is required once Node is installed.

Use test usernames seller.a, seller.b, rider.a, rider.b and admin with the fake password DemoOnly10!. Follow demo-guide.md. Use sample-proof.png for the harmless image example. Press Alt+Shift+R and confirm Restore data before presenting. Use the same browser and address for all roles.

This is a React frontend prototype with fictional data in localStorage. Login, permissions, account state and uploads are simulated in the browser. Initial accounts use the same fake password. Password changes and new account passwords live only in page memory and reset on refresh. No Next.js, PostgreSQL/RLS, real password storage, private server storage or cloud hosting is implemented here. Public display filtering does not remove synthetic private data from browser storage. Use no real recipient details or personal pictures.

Source and full implementation plans: https://github.com/Naszrul-NZL/ParcelTrack-Lite
